from src.db import (
    add_audit, add_feedback, create_user, get_setting, init_db,
    insert_prediction, list_audit, list_feedback, list_predictions,
    set_setting, user_count,
)
from src.security import hash_password


def test_database_user_prediction_feedback_and_audit(tmp_path):
    db_path = tmp_path / "test.sqlite"
    init_db(0.4, db_path=db_path)
    salt, digest = hash_password("Test-Password-Only-For-Unit-Tests!")
    create_user("reviewer", salt, digest, "analyst", db_path=db_path)
    assert user_count(db_path=db_path) == 1

    prediction_id = insert_prediction(
        "TEST-001", {"amount": 1000}, 0.8, "High", True, "reviewer", db_path=db_path
    )
    add_feedback(prediction_id, "reviewer", "confirmed_fraud", "Test record", db_path=db_path)
    set_setting("threshold", "0.6", "reviewer", db_path=db_path)
    add_audit("reviewer", "UNIT_TEST", "Test event", db_path=db_path)

    assert len(list_predictions(flagged_only=True, db_path=db_path)) == 1
    assert len(list_feedback(db_path=db_path)) == 1
    assert len(list_audit(db_path=db_path)) == 1
    assert get_setting("threshold", db_path=db_path) == "0.6"
