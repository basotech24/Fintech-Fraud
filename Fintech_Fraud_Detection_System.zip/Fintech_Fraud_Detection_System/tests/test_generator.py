from src.generate_data import generate_dataset


def test_default_generator_matches_project_dataset_size_and_prevalence():
    data = generate_dataset()
    assert len(data) == 20_000
    assert int(data["is_fraud"].sum()) == 224
    assert set(data["is_fraud"].unique()) == {0, 1}
