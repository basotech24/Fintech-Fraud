import pandas as pd
import pytest

from src.features import FEATURE_COLUMNS, build_features, validate_transactions


def sample_record():
    return {
        "user_type": "student", "channel": "transfer", "transaction_type": "purchase",
        "hour": 2, "amount": 250000, "sender_balance_before": 260000,
        "sender_balance_after": 10000, "receiver_account_age_days": 3,
        "is_new_device": 1, "is_new_location": 1, "txn_count_1h": 4,
        "txn_count_24h": 6, "avg_amount_30d": 5000, "failed_attempts": 2,
    }


def test_feature_builder_returns_29_fixed_columns():
    raw = validate_transactions(sample_record())
    features = build_features(raw)
    assert features.shape == (1, 29)
    assert list(features.columns) == FEATURE_COLUMNS
    assert features.iloc[0]["night"] == 1
    assert features.iloc[0]["amount_ratio"] > 40


def test_invalid_category_is_rejected():
    row = sample_record()
    row["channel"] = "unknown_channel"
    with pytest.raises(ValueError, match="Invalid value"):
        validate_transactions(row)


def test_missing_required_column_is_rejected():
    row = sample_record()
    row.pop("amount")
    with pytest.raises(ValueError, match="Missing required"):
        validate_transactions(row)


def test_numeric_empty_values_are_filled_with_zero():
    row = sample_record()
    row["failed_attempts"] = ""
    clean = validate_transactions(row)
    assert clean.loc[0, "failed_attempts"] == 0


def test_extra_columns_are_rejected_to_prevent_unneeded_personal_data():
    row = sample_record()
    row["account_number"] = "0000000000"
    with pytest.raises(ValueError, match="Unsupported column"):
        validate_transactions(row)
