import pytest

from src.security import hash_password, verify_password


def test_password_hash_verification():
    password = "Strong-Local-Password-2026!"
    salt, digest = hash_password(password)
    assert verify_password(password, salt, digest)
    assert not verify_password("wrong password", salt, digest)


def test_password_minimum_length():
    with pytest.raises(ValueError):
        hash_password("short")
