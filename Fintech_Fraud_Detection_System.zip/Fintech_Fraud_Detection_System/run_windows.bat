@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Creating Python virtual environment...
    python -m venv .venv
    if errorlevel 1 goto error
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 goto error

echo Installing required packages...
python -m pip install --upgrade pip
if errorlevel 1 goto error
pip install -r requirements.txt
if errorlevel 1 goto error

if not exist "data\transactions.csv" (
    echo Generating synthetic transaction data...
    python -m src.generate_data
    if errorlevel 1 goto error
)
if not exist "models\model.joblib" (
    echo Training fraud detection models...
    python -m src.train
    if errorlevel 1 goto error
)

echo Starting FinTrust web application...
streamlit run app.py
if errorlevel 1 goto error
goto end

:error
echo.
echo An error occurred. Check that Python is installed and available on PATH.
pause
:end
endlocal
