#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -x ".venv/bin/python" ]]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt

if [[ ! -f "data/transactions.csv" ]]; then
  python -m src.generate_data
fi
if [[ ! -f "models/model.joblib" ]]; then
  python -m src.train
fi

streamlit run app.py
