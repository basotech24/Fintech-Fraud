"""Model loading and transaction scoring helpers."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd

from src.features import build_features, risk_indicators, validate_transactions

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "model.joblib"
METRICS_PATH = ROOT / "models" / "metrics.json"


def load_model_bundle(path: Path | str = MODEL_PATH) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError("The trained model is missing. Run 'python -m src.train' first.")
    bundle = joblib.load(path)
    if not isinstance(bundle, dict) or "model" not in bundle:
        raise ValueError("The model file has an unexpected format. Retrain the model.")
    return bundle


def load_metrics(path: Path | str = METRICS_PATH) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def score_transactions(records: pd.DataFrame | dict | list[dict], threshold: float, *, max_rows: int = 50_000) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw = validate_transactions(records, max_rows=max_rows)
    features = build_features(raw)
    bundle = load_model_bundle()
    probabilities = bundle["model"].predict_proba(features)[:, 1]

    results = raw.copy()
    results["fraud_probability"] = probabilities
    results["risk_level"] = [
        "High" if p >= threshold else ("Medium" if p >= threshold * 0.5 else "Low")
        for p in probabilities
    ]
    results["flagged"] = probabilities >= threshold
    results["risk_indicators"] = [
        "; ".join(risk_indicators(row)) for row in raw.to_dict(orient="records")
    ]
    if "transaction_id" not in results.columns:
        results.insert(0, "transaction_id", [f"TXN-{i + 1:06d}" for i in range(len(results))])
    else:
        blanks = results["transaction_id"].astype(str).str.strip().eq("")
        if blanks.any():
            results.loc[blanks, "transaction_id"] = [f"TXN-{i + 1:06d}" for i in np.flatnonzero(blanks)]
    return results, raw
