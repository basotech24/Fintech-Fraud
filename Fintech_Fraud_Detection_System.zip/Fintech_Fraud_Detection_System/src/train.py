"""Train, compare and save the selected fraud-detection model."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from src.features import FEATURE_COLUMNS, TARGET_COLUMN, build_features, validate_transactions

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "transactions.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "model.joblib"
METRICS_PATH = MODEL_DIR / "metrics.json"
RANDOM_SEED = 42


def choose_threshold(y_true: pd.Series, probabilities: np.ndarray) -> float:
    precision, recall, thresholds = precision_recall_curve(y_true, probabilities)
    if len(thresholds) == 0:
        return 0.5
    denominator = precision[:-1] + recall[:-1]
    f1_values = np.divide(
        2 * precision[:-1] * recall[:-1], denominator,
        out=np.zeros_like(denominator), where=denominator > 0,
    )
    best = int(np.nanargmax(f1_values))
    return float(np.clip(thresholds[best], 0.001, 0.999))


def _safe_auc(fn, y_true, probabilities) -> float | None:
    try:
        return float(fn(y_true, probabilities))
    except ValueError:
        return None


def evaluate_at_threshold(y_true, probabilities, threshold: float) -> dict[str, Any]:
    predictions = (np.asarray(probabilities) >= threshold).astype(int)
    cm = confusion_matrix(y_true, predictions, labels=[0, 1])
    tn, fp, fn, tp = (int(x) for x in cm.ravel())
    return {
        "threshold": float(threshold),
        "precision": float(precision_score(y_true, predictions, zero_division=0)),
        "recall": float(recall_score(y_true, predictions, zero_division=0)),
        "f1": float(f1_score(y_true, predictions, zero_division=0)),
        "roc_auc": _safe_auc(roc_auc_score, y_true, probabilities),
        "pr_auc": float(average_precision_score(y_true, probabilities)),
        "accuracy": float(accuracy_score(y_true, predictions)),
        "mcc": float(matthews_corrcoef(y_true, predictions)),
        "confusion_matrix": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
        "test_rows": int(len(y_true)),
        "fraud_rows": int(np.asarray(y_true).sum()),
    }


def make_models() -> dict[str, Any]:
    return {
        "Logistic Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("classifier", LogisticRegression(
                class_weight="balanced", max_iter=2_000, random_state=RANDOM_SEED,
                solver="lbfgs",
            )),
        ]),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, class_weight="balanced_subsample", random_state=RANDOM_SEED,
            n_jobs=-1, min_samples_leaf=2,
        ),
        "Gradient Boosting": HistGradientBoostingClassifier(
            max_iter=150, learning_rate=0.08, max_leaf_nodes=15,
            l2_regularization=1.0, class_weight="balanced", random_state=RANDOM_SEED,
        ),
    }


def train_and_save(dataset_path: Path | str = DATA_PATH) -> dict[str, Any]:
    dataset_path = Path(dataset_path)
    if not dataset_path.exists():
        raise FileNotFoundError(f"Dataset not found: {dataset_path}. Run: python -m src.generate_data")

    raw = pd.read_csv(dataset_path)
    raw = validate_transactions(raw, require_label=True, max_rows=250_000)
    X = build_features(raw)
    y = raw[TARGET_COLUMN].astype(int)
    if y.sum() < 10:
        raise ValueError("At least 10 fraudulent examples are required for a reliable stratified training split.")

    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.40, random_state=RANDOM_SEED, stratify=y,
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, random_state=RANDOM_SEED, stratify=y_temp,
    )

    comparison: dict[str, dict[str, Any]] = {}
    fitted_models: dict[str, Any] = {}
    validation_probabilities: dict[str, np.ndarray] = {}
    for name, model in make_models().items():
        model.fit(X_train, y_train)
        probabilities = model.predict_proba(X_val)[:, 1]
        threshold = choose_threshold(y_val, probabilities)
        metrics = evaluate_at_threshold(y_val, probabilities, threshold)
        metrics["validation_pr_auc"] = float(average_precision_score(y_val, probabilities))
        metrics["validation_roc_auc"] = _safe_auc(roc_auc_score, y_val, probabilities)
        metrics["validation_precision"] = metrics["precision"]
        metrics["validation_recall"] = metrics["recall"]
        metrics["validation_f1"] = metrics["f1"]
        comparison[name] = metrics
        fitted_models[name] = model
        validation_probabilities[name] = probabilities

    selected_name = max(comparison, key=lambda key: comparison[key]["validation_pr_auc"])
    selected_model = fitted_models[selected_name]
    selected_threshold = float(comparison[selected_name]["threshold"])
    test_probabilities = selected_model.predict_proba(X_test)[:, 1]
    test_metrics = evaluate_at_threshold(y_test, test_probabilities, selected_threshold)

    # Persist model metadata and transparent experiment metrics.
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    bundle = {
        "model": selected_model,
        "model_name": selected_name,
        "threshold": selected_threshold,
        "feature_columns": FEATURE_COLUMNS,
        "trained_at": pd.Timestamp.utcnow().isoformat(),
    }
    joblib.dump(bundle, MODEL_PATH)

    result = {
        "dataset": {
            "rows": int(len(raw)),
            "fraud_rows": int(y.sum()),
            "fraud_rate": float(y.mean()),
            "train_rows": int(len(X_train)),
            "validation_rows": int(len(X_val)),
            "test_rows": int(len(X_test)),
        },
        "selected_model": selected_name,
        "threshold": selected_threshold,
        "validation_comparison": comparison,
        "test_metrics": test_metrics,
        "feature_count": int(X.shape[1]),
        "feature_columns": FEATURE_COLUMNS,
        "trained_at": bundle["trained_at"],
        "synthetic_data_notice": "This model was trained on synthetic project data, not live bank or GSU transaction records.",
    }
    METRICS_PATH.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Selected model: {selected_name}")
    print(f"Validation PR-AUC: {comparison[selected_name]['validation_pr_auc']:.4f}")
    print(f"Test precision: {test_metrics['precision']:.4f}; recall: {test_metrics['recall']:.4f}; F1: {test_metrics['f1']:.4f}")
    print(f"Saved model to {MODEL_PATH}")
    return result


def main() -> None:
    train_and_save()


if __name__ == "__main__":
    main()
