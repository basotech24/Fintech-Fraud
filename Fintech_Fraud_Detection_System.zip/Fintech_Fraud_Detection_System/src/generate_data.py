"""Create a reproducible synthetic Nigerian fintech transaction dataset."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATA_PATH = DATA_DIR / "transactions.csv"
RANDOM_SEED = 42
N_TRANSACTIONS = 20_000
N_FRAUD = 224  # 1.12%, matching the project report's synthetic dataset size/prevalence.


def generate_dataset(n: int = N_TRANSACTIONS, seed: int = RANDOM_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    user_type = rng.choice(["student", "staff", "vendor"], size=n, p=[0.72, 0.20, 0.08])
    channel = rng.choice(["pos", "transfer", "ussd", "web", "mobile_app"], size=n, p=[0.22, 0.34, 0.18, 0.08, 0.18])
    transaction_type = rng.choice(
        ["school_fees", "purchase", "transfer", "airtime_data", "cash_out", "other"],
        size=n,
        p=[0.12, 0.29, 0.27, 0.12, 0.12, 0.08],
    )

    # Campus-like spending patterns: students tend to transact smaller amounts;
    # staff have regular larger transfers; vendors receive many sales payments.
    user_scale = np.select([user_type == "staff", user_type == "vendor"], [2.8, 1.5], default=1.0)
    avg_amount_30d = np.maximum(300, rng.lognormal(mean=np.log(5_000), sigma=0.85, size=n) * user_scale)
    amount = np.maximum(100, rng.lognormal(mean=np.log(avg_amount_30d), sigma=0.78, size=n))

    # Fee payments are occasionally larger than a student's normal spend.
    fee_mask = transaction_type == "school_fees"
    amount[fee_mask] *= rng.uniform(2.0, 9.0, size=fee_mask.sum())

    hour = rng.choice(np.arange(24), size=n, p=np.array([
        .008, .006, .005, .004, .004, .006, .015, .035, .065, .075, .075, .07,
        .07, .07, .07, .07, .07, .07, .07, .06, .045, .025, .012, .01
    ]) / np.sum([
        .008, .006, .005, .004, .004, .006, .015, .035, .065, .075, .075, .07,
        .07, .07, .07, .07, .07, .07, .07, .06, .045, .025, .012, .01
    ]))

    # Keep balances non-negative and generate a realistic post-transaction balance.
    sender_balance_before = np.maximum(amount * rng.uniform(1.05, 8.0, size=n), rng.lognormal(np.log(25_000), 1.0, size=n))
    sender_balance_after = np.maximum(sender_balance_before - amount, 0)
    # A smaller subset exhibits a near-drain pattern.
    drain_candidates = rng.random(n) < 0.06
    sender_balance_before[drain_candidates] = amount[drain_candidates] * rng.uniform(1.0, 1.3, size=drain_candidates.sum())
    sender_balance_after[drain_candidates] = np.maximum(sender_balance_before[drain_candidates] - amount[drain_candidates], 0)

    receiver_account_age_days = np.clip(rng.gamma(shape=2.0, scale=180.0, size=n), 0, 3_000)
    is_new_device = rng.binomial(1, 0.055, size=n)
    is_new_location = rng.binomial(1, 0.045, size=n)
    txn_count_1h = rng.poisson(lam=0.65, size=n)
    txn_count_24h = txn_count_1h + rng.poisson(lam=2.2, size=n)
    failed_attempts = rng.choice([0, 1, 2, 3, 4], size=n, p=[.88, .08, .025, .01, .005])

    frame = pd.DataFrame({
        "transaction_id": [f"GSU-{i + 1:06d}" for i in range(n)],
        "user_type": user_type,
        "channel": channel,
        "transaction_type": transaction_type,
        "hour": hour.astype(int),
        "amount": amount.round(2),
        "sender_balance_before": sender_balance_before.round(2),
        "sender_balance_after": sender_balance_after.round(2),
        "receiver_account_age_days": receiver_account_age_days.round(0).astype(int),
        "is_new_device": is_new_device,
        "is_new_location": is_new_location,
        "txn_count_1h": txn_count_1h,
        "txn_count_24h": txn_count_24h,
        "avg_amount_30d": avg_amount_30d.round(2),
        "failed_attempts": failed_attempts,
    })

    amount_ratio = frame["amount"] / (frame["avg_amount_30d"] + 1.0)
    night = ((frame["hour"] >= 23) | (frame["hour"] <= 4)).astype(int)
    drain_ratio = frame["amount"] / (frame["sender_balance_before"] + 1.0)
    new_receiver = (frame["receiver_account_age_days"] <= 7).astype(int)
    high_velocity = ((frame["txn_count_1h"] >= 3) | (frame["txn_count_24h"] >= 10)).astype(int)
    high_risk_channel = frame["channel"].isin(["ussd", "web"]).astype(int)
    cash_out = (frame["transaction_type"] == "cash_out").astype(int)

    # A logistic-style linear risk score combines the 29 model signals and is used
    # to assign the synthetic fraud labels at the target prevalence.
    logit = (
        -6.0
        + 0.20 * amount_ratio
        + 1.35 * night
        + 1.45 * frame["is_new_device"]
        + 1.25 * frame["is_new_location"]
        - 0.0035 * frame["receiver_account_age_days"]
        + 0.38 * frame["txn_count_1h"]
        + 0.06 * frame["txn_count_24h"]
        + 0.65 * frame["failed_attempts"]
        + 1.30 * drain_ratio
        + 0.45 * high_risk_channel
        + 0.35 * cash_out
    )
    ranking_score = logit + rng.normal(0, 0.06, size=n)

    # Fixed minority-class count makes the experiment reproducible and matches the
    # report's 224/20,000 fraud prevalence. The label cutoff is the logistic-risk
    # score's upper 1.12% tail rather than a live bank label.
    fraud_count = min(N_FRAUD, max(1, int(round(n * 0.0112))))
    fraud_indices = np.argpartition(ranking_score, -fraud_count)[-fraud_count:]
    labels = np.zeros(n, dtype=int)
    labels[fraud_indices] = 1
    frame["is_fraud"] = labels
    return frame


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df = generate_dataset()
    df.to_csv(DATA_PATH, index=False)
    print(f"Generated {len(df):,} transactions at {DATA_PATH}")
    print(f"Fraudulent: {int(df['is_fraud'].sum()):,} ({df['is_fraud'].mean():.2%})")


if __name__ == "__main__":
    main()
