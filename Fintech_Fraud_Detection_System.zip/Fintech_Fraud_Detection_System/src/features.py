"""Shared input validation and feature engineering for training and scoring."""
from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd

CATEGORIES = {
    "user_type": ["student", "staff", "vendor"],
    "channel": ["pos", "transfer", "ussd", "web", "mobile_app"],
    "transaction_type": ["school_fees", "purchase", "transfer", "airtime_data", "cash_out", "other"],
}

NUMERIC_BASE_FIELDS = [
    "hour",
    "amount",
    "sender_balance_before",
    "sender_balance_after",
    "receiver_account_age_days",
    "is_new_device",
    "is_new_location",
    "txn_count_1h",
    "txn_count_24h",
    "avg_amount_30d",
    "failed_attempts",
]

REQUIRED_COLUMNS = [
    "user_type",
    "channel",
    "transaction_type",
    *NUMERIC_BASE_FIELDS,
]
OPTIONAL_COLUMNS = ["transaction_id"]
TARGET_COLUMN = "is_fraud"

FEATURE_COLUMNS = (
    NUMERIC_BASE_FIELDS
    + ["amount_ratio", "night", "balance_mismatch", "drain_ratio"]
    + [f"channel_{x}" for x in CATEGORIES["channel"]]
    + [f"type_{x}" for x in CATEGORIES["transaction_type"]]
    + [f"user_{x}" for x in CATEGORIES["user_type"]]
)


def _as_dataframe(records: pd.DataFrame | dict | list[dict]) -> pd.DataFrame:
    if isinstance(records, pd.DataFrame):
        return records.copy()
    if isinstance(records, dict):
        return pd.DataFrame([records])
    return pd.DataFrame(records)


def validate_transactions(
    records: pd.DataFrame | dict | list[dict],
    *,
    require_label: bool = False,
    max_rows: int = 50_000,
) -> pd.DataFrame:
    """Validate raw transaction records and return a normalised copy.

    Empty numeric cells are treated as zero to match the project methodology. Non-empty
    non-numeric values, unknown categories and invalid ranges are rejected.
    """
    df = _as_dataframe(records)
    if df.empty:
        raise ValueError("The file contains no transaction rows.")
    if len(df) > max_rows:
        raise ValueError(f"The file contains {len(df):,} rows. The maximum allowed is {max_rows:,}.")

    required = list(REQUIRED_COLUMNS)
    if require_label:
        required.append(TARGET_COLUMN)
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError("Missing required column(s): " + ", ".join(missing))

    allowed_columns = set(REQUIRED_COLUMNS + OPTIONAL_COLUMNS + ([TARGET_COLUMN] if require_label else []))
    unexpected = [column for column in df.columns if column not in allowed_columns]
    if unexpected:
        raise ValueError(
            "Unsupported column(s): " + ", ".join(map(str, unexpected[:10]))
            + ". Remove extra or personal fields; only project transaction fields are accepted."
        )

    for col, allowed in CATEGORIES.items():
        values = df[col].astype("string").str.strip().str.lower()
        invalid = sorted(set(values.dropna().tolist()) - set(allowed))
        if values.isna().any() or (values == "").any():
            raise ValueError(f"Column '{col}' contains an empty value.")
        if invalid:
            raise ValueError(f"Invalid value(s) in '{col}': {', '.join(invalid[:8])}. Allowed: {', '.join(allowed)}.")
        df[col] = values.astype(str)

    for col in NUMERIC_BASE_FIELDS:
        original = df[col]
        converted = pd.to_numeric(original, errors="coerce")
        bad = converted.isna() & original.notna() & (original.astype(str).str.strip() != "")
        if bad.any():
            raise ValueError(f"Column '{col}' contains non-numeric value(s).")
        df[col] = converted.fillna(0).astype(float)

    if require_label:
        labels = pd.to_numeric(df[TARGET_COLUMN], errors="coerce")
        if labels.isna().any() or not set(labels.unique()).issubset({0, 1}):
            raise ValueError("'is_fraud' must contain only 0 (legitimate) or 1 (fraudulent).")
        if labels.nunique() < 2:
            raise ValueError("Training data must contain both legitimate and fraudulent examples.")
        df[TARGET_COLUMN] = labels.astype(int)

    if ((df["hour"] < 0) | (df["hour"] > 23)).any():
        raise ValueError("'hour' must be between 0 and 23.")
    nonnegative = [
        "amount", "sender_balance_before", "sender_balance_after",
        "receiver_account_age_days", "txn_count_1h", "txn_count_24h",
        "avg_amount_30d", "failed_attempts",
    ]
    for col in nonnegative:
        if (df[col] < 0).any():
            raise ValueError(f"'{col}' cannot contain negative values.")
    for col in ["is_new_device", "is_new_location"]:
        if not df[col].isin([0, 1]).all():
            raise ValueError(f"'{col}' must contain only 0 or 1.")

    if "transaction_id" in df.columns:
        df["transaction_id"] = df["transaction_id"].astype("string").fillna("").astype(str)
    return df.reset_index(drop=True)


def build_features(records: pd.DataFrame | dict | list[dict]) -> pd.DataFrame:
    """Build the same fixed 29-column matrix for model training and inference."""
    df = _as_dataframe(records)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Cannot build features; missing: " + ", ".join(missing))

    out = pd.DataFrame(index=df.index)
    for col in NUMERIC_BASE_FIELDS:
        out[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(float)

    amount = out["amount"]
    average = out["avg_amount_30d"]
    before = out["sender_balance_before"]
    after = out["sender_balance_after"]
    hour = out["hour"]

    out["amount_ratio"] = amount / (average + 1.0)
    out["night"] = ((hour >= 23) | (hour <= 4)).astype(int)
    out["balance_mismatch"] = (before - amount - after).abs()
    out["drain_ratio"] = amount / (before + 1.0)

    for field, categories, prefix in (
        ("channel", CATEGORIES["channel"], "channel"),
        ("transaction_type", CATEGORIES["transaction_type"], "type"),
        ("user_type", CATEGORIES["user_type"], "user"),
    ):
        series = df[field].astype(str).str.strip().str.lower()
        for category in categories:
            out[f"{prefix}_{category}"] = (series == category).astype(int)

    # Fixed ordering is important: the model receives exactly the same 29 fields every time.
    return out.reindex(columns=FEATURE_COLUMNS, fill_value=0).astype(float)


def risk_indicators(record: dict | pd.Series, *, limit: int = 4) -> list[str]:
    """Produce concise, human-readable signals; these are not proof of fraud."""
    row = dict(record)
    amount = float(row.get("amount", 0) or 0)
    avg = float(row.get("avg_amount_30d", 0) or 0)
    before = float(row.get("sender_balance_before", 0) or 0)
    hour = int(float(row.get("hour", 0) or 0))
    indicators: list[str] = []

    if int(float(row.get("is_new_device", 0) or 0)) == 1:
        indicators.append("New device used")
    if int(float(row.get("is_new_location", 0) or 0)) == 1:
        indicators.append("New location detected")
    if hour >= 23 or hour <= 4:
        indicators.append("Transaction at night")
    if amount / (avg + 1.0) >= 3:
        indicators.append("Amount is far above the user's average")
    if float(row.get("receiver_account_age_days", 999999) or 0) <= 7:
        indicators.append("Receiver account is very new")
    if float(row.get("failed_attempts", 0) or 0) >= 2:
        indicators.append("Repeated failed attempts")
    if float(row.get("txn_count_1h", 0) or 0) >= 3 or float(row.get("txn_count_24h", 0) or 0) >= 10:
        indicators.append("High transaction frequency")
    if before > 0 and amount / (before + 1.0) >= 0.8:
        indicators.append("Transaction uses most of the available balance")
    if str(row.get("transaction_type", "")) == "cash_out" and amount >= 50_000:
        indicators.append("Large cash-out transaction")
    return indicators[:limit]
