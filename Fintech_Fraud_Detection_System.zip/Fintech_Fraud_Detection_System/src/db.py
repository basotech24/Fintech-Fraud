"""SQLite persistence for users, predictions, analyst feedback, audit and settings."""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from typing import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "fraud_detection.db"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connect(db_path: str | Path = DB_PATH) -> Iterator[sqlite3.Connection]:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(default_threshold: float = 0.5, db_path: str | Path = DB_PATH) -> None:
    with connect(db_path) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            salt TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('administrator','analyst','viewer')),
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference TEXT NOT NULL,
            features_json TEXT NOT NULL,
            probability REAL NOT NULL,
            risk TEXT NOT NULL CHECK(risk IN ('Low','Medium','High')),
            flagged INTEGER NOT NULL CHECK(flagged IN (0,1)),
            scored_by TEXT NOT NULL,
            source TEXT NOT NULL DEFAULT 'single',
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_predictions_flagged_probability
            ON predictions(flagged, probability DESC);
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prediction_id INTEGER NOT NULL REFERENCES predictions(id) ON DELETE CASCADE,
            analyst TEXT NOT NULL,
            verdict TEXT NOT NULL CHECK(verdict IN ('confirmed_fraud','false_positive')),
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_by TEXT NOT NULL DEFAULT 'system',
            updated_at TEXT NOT NULL
        );
        """)
        conn.execute(
            "INSERT OR IGNORE INTO settings(key,value,updated_by,updated_at) VALUES('threshold',?,?,?)",
            (str(float(default_threshold)), "system", utc_now()),
        )


def user_count(db_path: str | Path = DB_PATH) -> int:
    with connect(db_path) as conn:
        return int(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])


def create_user(username: str, salt: str, password_hash: str, role: str, db_path: str | Path = DB_PATH) -> None:
    username = username.strip()
    if not username or len(username) < 3 or len(username) > 40:
        raise ValueError("Username must contain between 3 and 40 characters.")
    if role not in {"administrator", "analyst", "viewer"}:
        raise ValueError("Invalid user role.")
    with connect(db_path) as conn:
        conn.execute(
            "INSERT INTO users(username,salt,password_hash,role,created_at) VALUES(?,?,?,?,?)",
            (username, salt, password_hash, role, utc_now()),
        )


def get_user(username: str, db_path: str | Path = DB_PATH) -> dict[str, Any] | None:
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE username = ?", (username.strip(),)).fetchone()
        return dict(row) if row else None


def list_users(db_path: str | Path = DB_PATH) -> list[dict[str, Any]]:
    with connect(db_path) as conn:
        rows = conn.execute("SELECT id,username,role,created_at FROM users ORDER BY username").fetchall()
        return [dict(row) for row in rows]


def add_audit(username: str, action: str, details: str, db_path: str | Path = DB_PATH) -> None:
    with connect(db_path) as conn:
        conn.execute(
            "INSERT INTO audit(username,action,details,created_at) VALUES(?,?,?,?)",
            (username, action, details[:2000], utc_now()),
        )


def get_setting(key: str, default: str | None = None, db_path: str | Path = DB_PATH) -> str | None:
    with connect(db_path) as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return str(row[0]) if row else default


def set_setting(key: str, value: str, updated_by: str, db_path: str | Path = DB_PATH) -> None:
    with connect(db_path) as conn:
        conn.execute(
            "INSERT INTO settings(key,value,updated_by,updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_by=excluded.updated_by,updated_at=excluded.updated_at",
            (key, value, updated_by, utc_now()),
        )


def insert_prediction(
    reference: str, features: dict[str, Any], probability: float, risk: str,
    flagged: bool, scored_by: str, source: str = "single", db_path: str | Path = DB_PATH,
) -> int:
    with connect(db_path) as conn:
        cursor = conn.execute(
            "INSERT INTO predictions(reference,features_json,probability,risk,flagged,scored_by,source,created_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (reference, json.dumps(features, default=str), float(probability), risk, int(flagged), scored_by, source, utc_now()),
        )
        return int(cursor.lastrowid)


def insert_predictions_bulk(items: list[dict[str, Any]], scored_by: str, source: str = "batch", db_path: str | Path = DB_PATH) -> list[int]:
    ids: list[int] = []
    with connect(db_path) as conn:
        now = utc_now()
        for item in items:
            cursor = conn.execute(
                "INSERT INTO predictions(reference,features_json,probability,risk,flagged,scored_by,source,created_at) "
                "VALUES(?,?,?,?,?,?,?,?)",
                (item["reference"], json.dumps(item["features"], default=str), float(item["probability"]),
                 item["risk"], int(item["flagged"]), scored_by, source, now),
            )
            ids.append(int(cursor.lastrowid))
    return ids


def list_predictions(*, flagged_only: bool = False, limit: int = 500, db_path: str | Path = DB_PATH) -> list[dict[str, Any]]:
    query = "SELECT * FROM predictions"
    params: list[Any] = []
    if flagged_only:
        query += " WHERE flagged=1"
    query += " ORDER BY probability DESC, id DESC LIMIT ?"
    params.append(int(limit))
    with connect(db_path) as conn:
        rows = conn.execute(query, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            try:
                item["features"] = json.loads(item.pop("features_json"))
            except (TypeError, json.JSONDecodeError):
                item["features"] = {}
            result.append(item)
        return result


def add_feedback(prediction_id: int, analyst: str, verdict: str, note: str, db_path: str | Path = DB_PATH) -> None:
    if verdict not in {"confirmed_fraud", "false_positive"}:
        raise ValueError("Invalid feedback verdict.")
    with connect(db_path) as conn:
        conn.execute(
            "INSERT INTO feedback(prediction_id,analyst,verdict,note,created_at) VALUES(?,?,?,?,?)",
            (int(prediction_id), analyst, verdict, note[:1000], utc_now()),
        )


def list_feedback(limit: int = 500, db_path: str | Path = DB_PATH) -> list[dict[str, Any]]:
    with connect(db_path) as conn:
        rows = conn.execute(
            "SELECT f.*, p.reference, p.probability FROM feedback f "
            "JOIN predictions p ON p.id=f.prediction_id ORDER BY f.id DESC LIMIT ?",
            (int(limit),),
        ).fetchall()
        return [dict(row) for row in rows]


def list_audit(limit: int = 500, db_path: str | Path = DB_PATH) -> list[dict[str, Any]]:
    with connect(db_path) as conn:
        rows = conn.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
        return [dict(row) for row in rows]
