from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.db import (
    add_audit,
    add_feedback,
    create_user,
    get_setting,
    get_user,
    init_db,
    insert_prediction,
    insert_predictions_bulk,
    list_audit,
    list_feedback,
    list_predictions,
    list_users,
    set_setting,
    user_count,
)
from src.features import CATEGORIES, REQUIRED_COLUMNS, TARGET_COLUMN, risk_indicators, validate_transactions
from src.scoring import load_metrics, score_transactions
from src.security import hash_password, verify_password
from src.train import train_and_save

st.set_page_config(
    page_title="FinTrust | Fraud Detection",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Subtle interface styling; all security and role checks remain server-side in Python.
st.markdown("""
<style>
:root { --brand:#153a68; --brand2:#1e5b8f; --ink:#17263c; --muted:#6b7a90; }
.block-container { padding-top: 1.7rem; padding-bottom: 3rem; max-width: 1500px; }
[data-testid="stSidebar"] { border-right: 1px solid rgba(120,140,160,.2); }
.hero { background: linear-gradient(115deg,#102d52,#1d5c8e); color:white; border-radius:18px; padding:26px 30px; margin-bottom:22px; }
.hero h1 { margin:0; color:white; font-size:2rem; font-weight:750; }
.hero p { margin:.4rem 0 0; color:#d8e6f5; }
.panel { border:1px solid rgba(120,140,160,.24); border-radius:14px; padding:16px 18px; background:rgba(120,140,160,.035); }
.small-muted { color:#758398; font-size:.88rem; }
.risk-high { color:#b42318; font-weight:700; }
.risk-medium { color:#b54708; font-weight:700; }
.risk-low { color:#067647; font-weight:700; }
div[data-testid="stMetric"] { background:rgba(120,140,160,.06); padding:14px 16px; border-radius:14px; border:1px solid rgba(120,140,160,.16); }
</style>
""", unsafe_allow_html=True)


def _safe_metrics() -> dict:
    try:
        return load_metrics()
    except Exception:
        return {}


metrics = _safe_metrics()
initial_threshold = float(metrics.get("threshold", 0.5) or 0.5)
init_db(default_threshold=initial_threshold)


def hero(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def require_role(user: dict, allowed: set[str]) -> bool:
    if user.get("role") not in allowed:
        st.error("You do not have permission to access this page.")
        return False
    return True


def show_setup() -> None:
    hero("Welcome to FinTrust", "Initial system setup · Create the first administrator account")
    st.info("No users exist yet. Create a secure administrator account to initialise the application.")
    with st.form("setup_admin"):
        username = st.text_input("Administrator username", max_chars=40)
        password = st.text_input("Password (at least 12 characters)", type="password")
        confirm = st.text_input("Confirm password", type="password")
        submitted = st.form_submit_button("Create administrator", type="primary", use_container_width=True)
    if submitted:
        if len(username.strip()) < 3:
            st.error("Username must contain at least 3 characters.")
        elif password != confirm:
            st.error("The passwords do not match.")
        else:
            try:
                salt, digest = hash_password(password)
                create_user(username, salt, digest, "administrator")
                add_audit(username.strip(), "INITIAL_ADMIN_CREATED", "First administrator account created")
                st.success("Administrator account created. Sign in to continue.")
                st.rerun()
            except Exception as exc:
                st.error(str(exc))


def show_login() -> None:
    hero("FinTrust Fraud Intelligence", "Machine-learning decision support for Nigerian digital-payment transactions")
    left, right = st.columns([1.05, 0.95], gap="large")
    with left:
        st.subheader("Sign in")
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Sign in", type="primary", use_container_width=True)
        if submitted:
            record = get_user(username)
            if record and verify_password(password, record["salt"], record["password_hash"]):
                st.session_state["user"] = {
                    "username": record["username"],
                    "role": record["role"],
                }
                add_audit(record["username"], "LOGIN_SUCCESS", "User signed in")
                st.rerun()
            else:
                add_audit(username.strip() or "unknown", "LOGIN_FAILED", "Invalid login attempt")
                st.error("The username or password is incorrect.")
    with right:
        st.markdown("### What this application does")
        st.markdown(
            "- Scores one transaction or a CSV batch.\n"
            "- Displays fraud probability, risk level and warning indicators.\n"
            "- Lets authorised analysts review alerts and record outcomes.\n"
            "- Keeps an audit trail of important actions."
        )
        st.warning("This prototype uses synthetic training data. It is not connected to a bank, payment gateway or GSU payment system.")


def format_naira(value: float) -> str:
    return f"₦{value:,.2f}"


def display_prediction(result: pd.Series | dict, probability: float, threshold: float) -> None:
    flagged = probability >= threshold
    risk = "High" if flagged else ("Medium" if probability >= threshold * 0.5 else "Low")
    a, b, c = st.columns(3)
    a.metric("Fraud probability", f"{probability:.1%}")
    b.metric("Risk level", risk)
    c.metric("Current decision", "Flag for review" if flagged else "Not flagged")
    st.progress(min(max(float(probability), 0.0), 1.0))
    indicators = risk_indicators(result)
    if indicators:
        st.markdown("**Risk indicators**")
        for item in indicators:
            st.markdown(f"- {item}")
    else:
        st.success("No configured warning indicators were detected in the supplied fields.")
    st.caption("A risk score is a screening signal, not proof that fraud occurred. An authorised person must review any alert.")


def dashboard(user: dict) -> None:
    hero("Fraud Monitoring Dashboard", "Overview of model-scored transactions and analyst workload")
    predictions = list_predictions(limit=5_000)
    total = len(predictions)
    flagged = sum(int(x["flagged"]) for x in predictions)
    rate = (flagged / total * 100) if total else 0.0
    threshold = float(get_setting("threshold", "0.5") or 0.5)
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Transactions scored", f"{total:,}")
    m2.metric("Flagged for review", f"{flagged:,}")
    m3.metric("Flag rate", f"{rate:.1f}%")
    m4.metric("Decision threshold", f"{threshold:.3f}")

    left, right = st.columns([1.1, 1], gap="large")
    with left:
        st.subheader("Risk distribution")
        if predictions:
            risk_counts = pd.Series([p["risk"] for p in predictions]).value_counts().reindex(["Low", "Medium", "High"], fill_value=0)
            st.bar_chart(risk_counts.rename("Transactions"))
        else:
            st.info("No predictions have been recorded yet. Start by scoring a transaction.")
    with right:
        st.subheader("Model information")
        if metrics:
            st.write(f"**Active model:** {metrics.get('selected_model', 'Not available')}")
            test = metrics.get("test_metrics", {})
            c1, c2 = st.columns(2)
            c1.metric("Test precision", f"{test.get('precision', 0):.1%}")
            c2.metric("Test recall", f"{test.get('recall', 0):.1%}")
            c3, c4 = st.columns(2)
            c3.metric("Test F1-score", f"{test.get('f1', 0):.3f}")
            c4.metric("Test PR-AUC", f"{metrics.get('validation_comparison', {}).get(metrics.get('selected_model', ''), {}).get('validation_pr_auc', 0):.3f}")
        else:
            st.warning("Model metrics have not been generated. Ask an administrator to retrain the model.")

    st.subheader("Recent predictions")
    if predictions:
        recent = sorted(predictions, key=lambda x: x["id"], reverse=True)[:12]
        frame = pd.DataFrame([{
            "Reference": p["reference"], "Probability": f"{p['probability']:.1%}",
            "Risk": p["risk"], "Flagged": "Yes" if p["flagged"] else "No",
            "Scored by": p["scored_by"], "Time": p["created_at"],
        } for p in recent])
        st.dataframe(frame, use_container_width=True, hide_index=True)

    if metrics:
        st.subheader("Classifier comparison (validation set)")
        comparison = metrics.get("validation_comparison", {})
        if comparison:
            table = pd.DataFrame([{
                "Model": name,
                "Precision": vals.get("validation_precision", 0),
                "Recall": vals.get("validation_recall", 0),
                "F1-score": vals.get("validation_f1", 0),
                "ROC-AUC": vals.get("validation_roc_auc", 0),
                "PR-AUC": vals.get("validation_pr_auc", 0),
            } for name, vals in comparison.items()])
            st.dataframe(table.style.format({c: "{:.3f}" for c in table.columns if c != "Model"}), use_container_width=True, hide_index=True)
        cm = metrics.get("test_metrics", {}).get("confusion_matrix")
        if cm:
            st.caption("Selected model · held-out test-set confusion matrix")
            st.dataframe(pd.DataFrame(
                [[cm["tn"], cm["fp"]], [cm["fn"], cm["tp"]]],
                index=["Actual legitimate", "Actual fraud"],
                columns=["Predicted legitimate", "Predicted fraud"],
            ), use_container_width=True)
    st.caption("Training and evaluation metrics are based on the synthetic dataset bundled with this project, not live payment records.")


def score_page(user: dict) -> None:
    if not require_role(user, {"administrator", "analyst"}):
        return
    hero("Score a Transaction", "Enter transaction attributes and receive a model-based screening result")
    threshold = float(get_setting("threshold", "0.5") or 0.5)
    with st.form("score_single_form"):
        c1, c2, c3 = st.columns(3)
        with c1:
            user_type = st.selectbox("User type", CATEGORIES["user_type"])
            channel = st.selectbox("Payment channel", CATEGORIES["channel"])
            transaction_type = st.selectbox("Transaction type", CATEGORIES["transaction_type"])
            hour = st.slider("Hour of transaction", 0, 23, 13)
        with c2:
            amount = st.number_input("Transaction amount (₦)", min_value=0.0, value=1_500.0, step=500.0)
            avg_amount = st.number_input("Average amount in last 30 days (₦)", min_value=0.0, value=1_800.0, step=500.0)
            balance_before = st.number_input("Sender balance before (₦)", min_value=0.0, value=42_000.0, step=1_000.0)
            balance_after = st.number_input("Sender balance after (₦)", min_value=0.0, value=40_500.0, step=1_000.0)
        with c3:
            receiver_age = st.number_input("Receiver account age (days)", min_value=0, value=900, step=1)
            txn_1h = st.number_input("Transactions in last hour", min_value=0, value=1, step=1)
            txn_24h = st.number_input("Transactions in last 24 hours", min_value=0, value=3, step=1)
            failed = st.number_input("Failed attempts before transaction", min_value=0, value=0, step=1)
        d1, d2, d3 = st.columns(3)
        with d1:
            new_device = st.checkbox("New device")
        with d2:
            new_location = st.checkbox("New location")
        with d3:
            reference = st.text_input("Transaction reference (optional)", placeholder="Auto-generated when blank")
        submitted = st.form_submit_button("Analyse transaction", type="primary", use_container_width=True)

    if submitted:
        record = {
            "transaction_id": reference.strip() or f"TXN-{uuid.uuid4().hex[:10].upper()}",
            "user_type": user_type, "channel": channel, "transaction_type": transaction_type,
            "hour": hour, "amount": amount, "sender_balance_before": balance_before,
            "sender_balance_after": balance_after, "receiver_account_age_days": receiver_age,
            "is_new_device": int(new_device), "is_new_location": int(new_location),
            "txn_count_1h": txn_1h, "txn_count_24h": txn_24h,
            "avg_amount_30d": avg_amount, "failed_attempts": failed,
        }
        try:
            result, raw = score_transactions(record, threshold, max_rows=1)
            probability = float(result.iloc[0]["fraud_probability"])
            flagged = probability >= threshold
            risk = str(result.iloc[0]["risk_level"])
            prediction_id = insert_prediction(
                str(result.iloc[0]["transaction_id"]), record, probability, risk,
                flagged, user["username"], source="single",
            )
            add_audit(user["username"], "TRANSACTION_SCORED", f"Prediction ID {prediction_id}; flagged={flagged}; probability={probability:.6f}")
            st.markdown("---")
            display_prediction(record, probability, threshold)
            st.caption(f"Saved as prediction #{prediction_id} · Reference {result.iloc[0]['transaction_id']}")
        except Exception as exc:
            st.error(f"Could not score this transaction: {exc}")


def batch_page(user: dict) -> None:
    if not require_role(user, {"administrator", "analyst"}):
        return
    hero("Batch Upload", "Upload a CSV of transactions, validate it, score every row and download the results")
    st.markdown("The CSV must contain the 14 transaction fields specified in the project appendix. An optional `transaction_id` column is preserved.")
    st.code(",".join(REQUIRED_COLUMNS), language="text")
    uploaded = st.file_uploader("Choose a CSV file (maximum 50,000 rows)", type=["csv"], key="batch_csv")
    if uploaded is not None:
        try:
            raw = pd.read_csv(uploaded)
            st.write(f"Uploaded **{len(raw):,}** rows and **{len(raw.columns)}** columns.")
            if st.button("Validate and score batch", type="primary"):
                threshold = float(get_setting("threshold", "0.5") or 0.5)
                results, validated = score_transactions(raw, threshold, max_rows=50_000)
                storage_items = []
                for _, row in results.iterrows():
                    record = validated.iloc[int(row.name)].to_dict()
                    p = float(row["fraud_probability"])
                    storage_items.append({
                        "reference": str(row["transaction_id"]),
                        "features": record,
                        "probability": p,
                        "risk": str(row["risk_level"]),
                        "flagged": bool(row["flagged"]),
                    })
                ids = insert_predictions_bulk(storage_items, user["username"], source="batch")
                flagged_count = int(results["flagged"].sum())
                add_audit(user["username"], "BATCH_SCORED", f"Scored {len(results)} rows; {flagged_count} flagged; {len(ids)} predictions saved")
                st.session_state["batch_results"] = results
                st.success(f"Scored {len(results):,} transactions. {flagged_count:,} were flagged for review.")
        except Exception as exc:
            st.error(f"The batch could not be processed: {exc}")
    if "batch_results" in st.session_state:
        results = st.session_state["batch_results"]
        st.subheader("Scoring results")
        st.dataframe(results, use_container_width=True, hide_index=True)
        csv_data = results.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download scored results (CSV)", data=csv_data,
            file_name="fraud_scoring_results.csv", mime="text/csv", type="primary",
        )


def review_page(user: dict) -> None:
    if not require_role(user, {"administrator", "analyst"}):
        return
    hero("Review Flags", "Work through flagged transactions and record analyst feedback")
    flags = list_predictions(flagged_only=True, limit=500)
    if not flags:
        st.success("There are no flagged transactions in the review queue.")
        return
    table = pd.DataFrame([{
        "Prediction ID": p["id"], "Reference": p["reference"],
        "Probability": f"{p['probability']:.1%}", "Risk": p["risk"],
        "Scored by": p["scored_by"], "Created": p["created_at"],
    } for p in flags])
    st.dataframe(table, use_container_width=True, hide_index=True)
    selected_id = st.selectbox("Select a prediction to review", [p["id"] for p in flags], format_func=lambda x: next(f"#{p['id']} · {p['reference']} · {p['probability']:.1%}" for p in flags if p["id"] == x))
    chosen = next(p for p in flags if p["id"] == selected_id)
    with st.expander("Transaction attributes", expanded=True):
        st.json(chosen["features"])
        st.write(f"**Model probability:** {chosen['probability']:.1%} · **Risk:** {chosen['risk']}")
    with st.form("feedback_form"):
        verdict = st.selectbox("Analyst verdict", ["confirmed_fraud", "false_positive"], format_func=lambda x: "Confirmed fraud" if x == "confirmed_fraud" else "False positive")
        note = st.text_area("Review note (optional)", max_chars=1000)
        submitted = st.form_submit_button("Save analyst feedback", type="primary")
    if submitted:
        try:
            add_feedback(selected_id, user["username"], verdict, note)
            add_audit(user["username"], "ANALYST_FEEDBACK", f"Prediction {selected_id}; verdict={verdict}")
            st.success("Feedback saved to the review history.")
            st.rerun()
        except Exception as exc:
            st.error(str(exc))
    history = list_feedback(limit=20)
    if history:
        st.subheader("Recent analyst feedback")
        st.dataframe(pd.DataFrame([{
            "Prediction": f"#{x['prediction_id']} · {x['reference']}",
            "Verdict": "Confirmed fraud" if x["verdict"] == "confirmed_fraud" else "False positive",
            "Analyst": x["analyst"], "Note": x["note"], "Time": x["created_at"],
        } for x in history]), use_container_width=True, hide_index=True)


def awareness_page() -> None:
    hero("Fraud Awareness", "Practical safety guidance for students, staff and campus vendors")
    tips = [
        ("Fake payment alerts", "Check the actual balance and transaction history in your bank or wallet app. Do not release goods or treat a screenshot as proof of payment."),
        ("Phishing and fake fee portals", "Use the university's verified payment channels. Check the web address carefully and do not enter passwords, PINs or one-time codes on links sent in unsolicited messages."),
        ("SIM-swap and account takeover", "Contact your mobile network and bank promptly if your SIM unexpectedly stops working or you receive account-change alerts you did not request."),
        ("Social engineering", "Do not share your PIN, password or OTP with callers or people claiming to be bank or university officials. Genuine support staff should not ask you to disclose these secrets."),
        ("POS and transfer disputes", "Keep transaction references and receipts. Verify a reversal in the official account statement rather than relying on a verbal claim or edited screenshot."),
        ("New beneficiaries and unusual requests", "Confirm unexpected payment requests through a separate, trusted contact method before sending money."),
    ]
    for title, body in tips:
        with st.expander(title):
            st.write(body)
    st.info("Report suspected payment fraud through your bank or payment provider's official support channel and the appropriate university office. Do not post account numbers, BVNs, PINs or OTPs in public groups.")
    st.caption("This page provides general awareness guidance and does not replace advice from a financial institution or law-enforcement authority.")


def admin_page(user: dict) -> None:
    if not require_role(user, {"administrator"}):
        return
    hero("Administration", "Manage the decision threshold, model, users and accountability records")
    threshold_now = float(get_setting("threshold", "0.5") or 0.5)
    st.subheader("Decision threshold")
    with st.form("threshold_form"):
        new_threshold = st.slider("Flag a transaction when its fraud probability is at least", min_value=0.001, max_value=0.999, value=float(min(max(threshold_now, 0.001), 0.999)), step=0.001, format="%.3f")
        change = st.form_submit_button("Save threshold", type="primary")
    if change:
        set_setting("threshold", str(float(new_threshold)), user["username"])
        add_audit(user["username"], "THRESHOLD_CHANGED", f"Decision threshold changed from {threshold_now:.3f} to {new_threshold:.3f}")
        st.success("New decision threshold saved.")
        st.rerun()
    st.caption("A lower threshold generally flags more transactions for review; a higher threshold generally reduces alerts. This setting does not block or reverse payments.")

    st.markdown("---")
    st.subheader("Model and dataset")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("Retrain and evaluate models", use_container_width=True):
            with st.spinner("Training Logistic Regression, Random Forest and Gradient Boosting..."):
                try:
                    new_metrics = train_and_save()
                    set_setting("threshold", str(float(new_metrics["threshold"])), user["username"])
                    add_audit(user["username"], "MODEL_RETRAINED", f"Selected {new_metrics['selected_model']}; new threshold={new_metrics['threshold']:.6f}")
                    st.success(f"Training completed. Selected {new_metrics['selected_model']}.")
                    st.rerun()
                except Exception as exc:
                    st.error(f"Retraining failed: {exc}")
    with c2:
        if st.button("Show current model metrics", use_container_width=True):
            current = _safe_metrics()
            st.json({
                "selected_model": current.get("selected_model"),
                "threshold": current.get("threshold"),
                "dataset": current.get("dataset"),
                "test_metrics": current.get("test_metrics"),
            })

    replacement = st.file_uploader("Replace training dataset (CSV with is_fraud labels)", type=["csv"], key="replacement_dataset")
    if replacement is not None:
        if st.button("Validate and replace training dataset", type="secondary"):
            try:
                candidate = pd.read_csv(replacement)
                candidate = validate_transactions(candidate, require_label=True, max_rows=250_000)
                if int(candidate[TARGET_COLUMN].sum()) < 10:
                    raise ValueError("At least 10 fraud examples are required.")
                destination = ROOT / "data" / "transactions.csv"
                candidate.to_csv(destination, index=False)
                add_audit(user["username"], "DATASET_REPLACED", f"Replaced training dataset with {len(candidate)} rows")
                st.success("Training dataset replaced. Retrain the model to use the new data.")
            except Exception as exc:
                st.error(f"Dataset was not replaced: {exc}")

    st.markdown("---")
    st.subheader("Create user")
    with st.form("create_user_form"):
        new_username = st.text_input("New username", max_chars=40)
        new_password = st.text_input("Temporary password (at least 12 characters)", type="password")
        role = st.selectbox("Role", ["analyst", "viewer", "administrator"])
        create = st.form_submit_button("Create account")
    if create:
        try:
            salt, digest = hash_password(new_password)
            create_user(new_username, salt, digest, role)
            add_audit(user["username"], "USER_CREATED", f"Created user '{new_username.strip()}' with role '{role}'")
            st.success(f"User '{new_username.strip()}' created.")
            st.rerun()
        except Exception as exc:
            st.error(str(exc))
    users = list_users()
    if users:
        st.dataframe(pd.DataFrame(users), use_container_width=True, hide_index=True)

    st.markdown("---")
    st.subheader("Audit log")
    logs = list_audit(limit=250)
    if logs:
        st.dataframe(pd.DataFrame(logs), use_container_width=True, hide_index=True)
    else:
        st.info("No audit events have been recorded.")
    st.subheader("Feedback history")
    feedback = list_feedback(limit=250)
    if feedback:
        st.dataframe(pd.DataFrame(feedback), use_container_width=True, hide_index=True)
    else:
        st.info("No analyst feedback has been submitted yet.")


# First-run administrator bootstrap and authentication gate.
if user_count() == 0:
    show_setup()
    st.stop()

if "user" not in st.session_state:
    show_login()
    st.stop()

user = st.session_state["user"]
with st.sidebar:
    st.markdown("## 🛡️ FinTrust")
    st.caption("Financial transaction screening")
    st.markdown(f"**{user['username']}**  \n`{user['role'].replace('_', ' ').title()}`")
    st.divider()
    pages = ["Dashboard", "Fraud Awareness"]
    if user["role"] in {"administrator", "analyst"}:
        pages = ["Dashboard", "Score Transaction", "Batch Upload", "Review Flags", "Fraud Awareness"]
    if user["role"] == "administrator":
        pages.append("Admin")
    selected_page = st.radio("Navigation", pages, label_visibility="collapsed")
    st.divider()
    if st.button("Log out", use_container_width=True):
        add_audit(user["username"], "LOGOUT", "User signed out")
        st.session_state.pop("user", None)
        st.rerun()
    st.caption("Local prototype · synthetic data")

if selected_page == "Dashboard":
    dashboard(user)
elif selected_page == "Score Transaction":
    score_page(user)
elif selected_page == "Batch Upload":
    batch_page(user)
elif selected_page == "Review Flags":
    review_page(user)
elif selected_page == "Fraud Awareness":
    awareness_page()
elif selected_page == "Admin":
    admin_page(user)
